# Windows2019RDP-US
Windows Server 2019 Github with RDP Access (ngrok US) 

Repo link: https://github.com/kingremixyoutuber/Windows2019RDP-US

Real owner of the repo but something wrong with his github and here is the link: https://github.com/aloksharmakumar77

so i edit the codes its actually not working then with my some changes it start work again so enjoy now

Create a free VPS with 2cpu-7gb Ram FREE with Github:

+ Click Fork in the right corner of the screen to save it to your Github.
+ Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
+ In Github go to Settings> Secrets> New repository secret
+ In Name: enter NGROK_AUTH_TOKEN
+ In Value: visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste Your Authtoken into
+ Press Add secret
+ Go to Action> CI> Run workflow
+ Reload the page and press CI> build
+ Press the down arrow on Connect To Your RPD to get IP, User, Password.
